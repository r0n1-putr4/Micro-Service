# Salone - Free Bootstrap 5 Business Template 

- [Demo](https://themewagon.github.io/Electro-Bootstrap/)

#### Download

- [Download from ThemeWagon](https://themewagon.com/themes/electro-bootstrap/)

## Getting Started

Clone Repository

```
https://github.com/themewagon/Electro-Bootstrap.git
```

## Author

```
Salone is developed by Team HTML Codex.
```

## License

- Design and Code is Copyright &copy; [HTML Codex](https://htmlcodex.com/).
- Licensed cover under [MIT]
- Distributed by [ThemeWagon](https://themewagon.com)
